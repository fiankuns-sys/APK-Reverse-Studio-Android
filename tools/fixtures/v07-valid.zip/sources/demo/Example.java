package demo; public class Example { int answer = 42; }
